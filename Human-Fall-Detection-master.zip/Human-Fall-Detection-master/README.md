# Human-Fall-Detection
AI 딥러닝 기반 실시간 낙상 감지 시스템  


---  
### 사용방법
- 가상환경 만들기 `python -m venv test`
- 테스트 환경 활성화 `test\Scripts\activate`
- `pip install -r requirements.txt`
- `python App.py`
